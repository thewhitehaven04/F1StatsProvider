class LapIdentifier: 
    driver: str | int
    lap: int